# -*- coding: utf-8 -*-

bind = '0.0.0.0:8000'
accesslog = '-'
